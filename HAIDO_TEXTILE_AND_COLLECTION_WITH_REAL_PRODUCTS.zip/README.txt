HAIDO TEXTILE AND COLLECTION
Real product/store photos included.
Known prices: Black Leather Sandals ₦17,000; Brown Leather Sandals ₦10,000.
Other items are listed as Price on request.
Upload every file in this folder to the root of the GitHub repository, then enable GitHub Pages.
